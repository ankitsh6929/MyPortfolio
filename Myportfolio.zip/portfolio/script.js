document.addEventListener("DOMContentLoaded", function() {
    var downloadLink = document.getElementById("download-cv");
    downloadLink.addEventListener("click", function(event) {
        event.preventDefault(); // Prevent default link behavior
        window.open("CV_Ankit.pdf", "_blank"); // Use the relative path to your PDF file
    });
});
